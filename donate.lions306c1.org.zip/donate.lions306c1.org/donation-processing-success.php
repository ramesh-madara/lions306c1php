<!DOCTYPE html>
<html>
<head>
  <title>Thank You for Your Donation</title>
  <link rel="stylesheet" type="text/css" href="css/thankyou-page-style.css">
</head>
<body>
  <div class="container">
    <h1>Thank You for Your Donation!</h1>
    <p>Your generous contribution will make a difference in our cause.</p>
    <p>We greatly appreciate your support.</p>
  </div>
</body>
</html>
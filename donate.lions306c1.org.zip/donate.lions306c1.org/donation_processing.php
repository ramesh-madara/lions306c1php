<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

/**
 * Function to send the payment request to the payment gateway.
 */
function sendPaymentRequest($gatewayURL, $apiUsername, $apiPassword, $merchant, $orderId, $orderamount, $interactionreturnUrl)
{
    $orderDiscription = "Donation id - $orderId";
    $data = [
        'apiOperation' => 'CREATE_CHECKOUT_SESSION',
        'apiUsername' => $apiUsername,
        'apiPassword' => $apiPassword,
        'merchant' => $merchant,
        'order.id' => $orderId,
        'order.amount' => $orderamount,
        'order.currency' => 'LKR',
        'order.description' => $orderDiscription,
        'interaction.operation' => 'PURCHASE',
        'interaction.returnUrl' => $interactionreturnUrl,
        'interaction.merchant.name' => 'LIONS CLUBS INTERNATIONAL'
    ];

    $curl = curl_init();
    curl_setopt_array($curl, [
        CURLOPT_URL => $gatewayURL,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => http_build_query($data),
        CURLOPT_HTTPHEADER => [
            'cache-control: no-cache',
            'content-type: application/x-www-form-urlencoded'
        ],
    ]);

    $response = curl_exec($curl);
    curl_close($curl);

    return $response;
}

/**
 * Function to save the donation details to the MySQL database.
 */
function createDonationOrderToDatabase($name, $email, $amount, $message)
{
    $servername = "localhost";
    $username = "lions306c1_donateusr";
    $password = "JlKX[*t3[=BA";
    $dbname = "lions306c1_donate";

    // Create a new database connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check the connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare the SQL statement to insert the donation details into the database
    $sql = "INSERT INTO `orders`(`customer_name`, `customer_email`, `total_amount`, `message`) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssds", $name, $email, $amount, $message);

    if ($stmt->execute()) {
        // Donation details were successfully saved to the database
        $orderId = $stmt->insert_id; // Get the ID of the inserted record

        // Close the prepared statement and the database connection
        $stmt->close();
        $conn->close();

        return $orderId; // Return the ID of the inserted record
    } else {
        // Error occurred while saving the donation details
        // Handle the error appropriately
        $stmt->close();
        $conn->close();

        return null; // Return null or an appropriate value to indicate an error
    }
}

try {
    // Check if the form was submitted
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        // Get the form data
        $name = $_POST["name"];
        $email = $_POST["email"];
        $amount = $_POST["amount"];
        $message = $_POST["message"];

        // Validate the form data (perform necessary checks)

        // Validate name field
        if (empty($name)) {
            $errors[] = "Please enter your name.";
        }

        // Validate email field
        if (empty($email)) {
            $errors[] = "Please enter your email address.";
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = "Please enter a valid email address.";
        }

        // Validate amount field
        if (empty($amount) || $amount <= 0) {
            $errors[] = "Please enter a valid donation amount.";
        }

        if (!empty($errors)) {
            header("Location: index.html");
            exit();
        } else {
            // Create order in database
            $orderId = createDonationOrderToDatabase($name, $email, $amount, $message);

            // Prepare the data for sending to the payment gateway
            $gatewayURL = 'https://cbcmpgs.gateway.mastercard.com/api/nvp/version/61';
            // $gatewayURL = 'https://test-gateway.mastercard.com/api/nvp/version/61';
            $apiUsername = 'merchant.TESTLIONSCLUBLKR';
            $apiPassword = '94caf5a8da9a8d25d23c9f55853db5af';
            $merchant = 'TESTLIONSCLUBLKR';
            $orderId = strval($orderId);
            $orderamount = number_format($amount, 2, '.', '');
            $interactionreturnUrl = "http://donate.lions306c1.org/donation-processing-success.php?orderid=$orderId";

            // Send the data to the payment gateway
            $gatewayResponse = sendPaymentRequest($gatewayURL, $apiUsername, $apiPassword, $merchant, $orderId, $orderamount, $interactionreturnUrl);

            // Parse the string into an associative array
            $gatewayResponseArray = [];
            parse_str($gatewayResponse, $gatewayResponseArray);
            // var_dump($gatewayResponseArray);
            // exit();
            // Process the response from the payment gateway
            if ($gatewayResponseArray['result'] !== "SUCCESS") {
                header("Location: index.html");
                exit();
            }
        }
    } else {
        header("Location: index.html");
        exit();
    }
} catch (Exception $e) {
    echo 'Message: ' . $e->getMessage();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Donate to lions-306c1</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <script src="https://cbcmpgs.gateway.mastercard.com/checkout/version/61/checkout.js"
            data-error="errorCallback" data-cancel="cancelCallback"></script>
</head>
<body>
<div class="container">
    <img src="img/logo.png" alt="Logo" class="header-image">
    <h1>Donate to lions-306c1</h1>
    <label for="name">Name: <?php echo $name; ?></label>

    <label for="email">Email: <?php echo $email; ?></label>

    <label for="message">Message: <?php echo $message; ?></label>
    <input type="button" value="Donate <?php echo $orderamount; ?> LKR" onclick="Checkout.showPaymentPage();"/>
</div>
<script type="text/javascript">
    function errorCallback(error) {
        console.log(JSON.stringify(error));
    }

    function cancelCallback() {
        console.log('Payment cancelled');
    }

    Checkout.configure({
        session: {
            id: '<?php echo $gatewayResponseArray["session_id"]; ?>'
        },
        interaction: {
            displayControl: { // you may change these settings as you prefer
                billingAddress: 'HIDE',
                customerEmail: 'HIDE',
                orderSummary: 'SHOW',
                shipping: 'HIDE'
            }
        }
    });
</script>
</body>
</html>
